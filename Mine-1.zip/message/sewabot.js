



exports.dada = (prefix, pushname, ucapanWaktu) => {
return `${ucapanWaktu} kak ${pushname}
Berikut adalah list harga untuk sewa bot


╭────✎「 *SEWA BOT* 」
│*Harga!*
│• Pengguna baru Rp. 20.000/group
│• Masa aktif 30 hari
│• Rp. 50.000/groub
│• Masa aktif 50 hari
╰─────────❍



╭────✎「 *PREMIUM* 」
│*Harga!*
│• Rp. 10.000/orang
│• Masa aktif 3 bulan
╰─────────❍

╭────✎「 *FITUR PREMIUM* 」
│*Listnya!*
│• Limit dan limit game tanpa batas
│• Claim lebih banyak EXP Harian
│• Ubah watermark sticker
│• dan masi banyak lagi
╰─────────❍



*PAYMENT*:
𖦹 Dana
𖦹 Pulsa
- 


_Silahkan ketik .owner untuk mengetahui pemilik bot ini_
`
}

const fs = require("fs");
const { color } = require("../lib/color");
const chalk = require('chalk')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})

    




















/*
const fs = require("fs");
const { color } = require("../lib/color");
const chalk = require('chalk')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})
*/