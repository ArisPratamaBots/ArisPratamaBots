const version = require("@adiwajshing/baileys/package.json").version

global.language = "id"
global.nomerOwner = ["6281368351787"]
global.instagram = "https://instagram.com/"
global.email = "arispratama1207@gmail.com"
global.runWith = "GeForce RTx3090"
global.botName = "Mine Bot" 
global.sessionName ="session"
global.setmenu ="location" 
global.docType = "docx"
global.public = false
global.baileysMd = true
global.antiSpam = true
global.multi = true
global.prefa = ","
global.fake = botName
global.Console = false
global.autorespon = false
global.copyright = `Bot WhatsApp⁰⁵`
global.baileysVersion = `Baileys ${version}`
global.On = "On"
global.Off ="Off"
global.autoblockcmd = false
global.fake1 ="Bot WhatsApp"
global.packName = "Create by"
global.authorName = "Aris_×"
global.replyType = "mess"
global.setwelcome = "type1"
global.autoblockcmd = false
global.autoReport = true
global.autoLevel = true
global.autoSticker = false
global.gamewaktu = 60
global.limitCount = 30
global.Intervalmsg = 1000 //detik
global.keylol = "77fd14202ab70eb09622d2d5"
global.rosekey = "Rs-ReiiNtNic"
global.apiwtf = "males"
global.apiwtf2 = "males"
global.apiwtf3 = "males"
global.azz = "global"
global.apionichan = "gkMf-FNYa-IqTH"
global.nobg = ["S2SFVrM7vQD8LdxEq5tZ1u2q"]
global.beta = "BetaBotz"
global.token = "13cc2eee-5315-4d84-b3c8-d5b05ce297c3"
global.fileStackApi ="AFkI0QMq1RgeyeQS2bZYSz" //daftar di filestack
global.gcounti = {
'prem' : 1000,
'user' : 20
} 


const fs = require("fs");
const { color } = require("./lib/color");
const chalk = require('chalk')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})






